## Courier-Management-System

The CMS is designed using Python.
Features: 1. Cost Estimation (using regression) 2. Creating Courier Request 3. Tracking Courier 4. Feedback 5. Creating New User

CMS project using Python
Important tips to run Courier Management System program:

1. Execute CMS.py only.
2. Do not alter data.csv file (unless you want to enter your own data).
3. If CMS.py giving any error, then make sure you are running the CMS.py file from correct directory (if not, then change directory to Courier-Management-System folder). (OR run the file in command line)
4. Other files are for testing the databases.
5. Admin ID: admin
   password: admin
   (To change this, go to CMS.py line no. 584)

6. Create your own account from 'New user' and then log in.
7. Watch cms.mp4 video to get overall understanding of the project.
