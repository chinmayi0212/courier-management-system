from django.apps import AppConfig


class CouriermanageConfig(AppConfig):
    name = 'couriermanage'
